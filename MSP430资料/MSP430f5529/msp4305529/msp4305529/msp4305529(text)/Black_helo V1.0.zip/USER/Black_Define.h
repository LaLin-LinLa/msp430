/*
 * Black_Define.h
 *
 *  Created on: 2020��10��7��
 *      Author: PC
 */

#ifndef USER_BLACK_DEFINE_H_
#define USER_BLACK_DEFINE_H_

#include <msp430.h>

#define LED0_Switch   0
#define LED1_Switch   0
#define KEY_Switch    0
#define USART0_switch 0
#define USART1_switch 0
#define PWM0_switch   0
#define PWM1_switch   0
#define PWM2_switch   0
#define PWM3_switch   0
#define OLED_switch   0

#endif /* USER_BLACK_DEFINE_H_ */

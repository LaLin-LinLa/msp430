/**
  * @file    main.c
  * @author  black helo
  * @version V1.0
  * @date    2020-10-08
  * @brief   ������
  */


#include "Black_All.h"

void main(void)
{
    Init();
    while(1);
}
